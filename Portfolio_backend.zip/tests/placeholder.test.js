import { describe, it, expect } from 'vitest';

describe('tooling sanity', () => {
  it('runs tests successfully', () => {
    expect(true).toBe(true);
  });
});
