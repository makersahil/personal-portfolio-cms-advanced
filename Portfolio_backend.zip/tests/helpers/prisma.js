// Use the app's Prisma singleton
import prisma from '../../src/config/db.js';

export default prisma;
