// src/routes/index.js
import fp from 'fastify-plugin';
import healthRoutes from './health.route.js';
import authRoutes from '../features/auth/auth.route.js';

/**
 * Central route hub.
 * Registers all route modules. For now: health.
 * Add feature routes here later with prefixes (e.g., /api/v1/...).
 */
export default fp(async (app) => {
  // Health routes → /health/live and /health/ready
  app.register(healthRoutes);

  // Example for later:
  app.register(authRoutes, { prefix: '/api/v1/auth' });
  // app.register(articleRoutes, { prefix: '/api/v1/articles' });
  // app.register(grantRoutes, { prefix: '/api/v1/grants' });
  // app.register(patentRoutes, { prefix: '/api/v1/patents' });
  // app.register(publicationRoutes, { prefix: '/api/v1/publications' });

  // TEMP DEBUG: list routes at startup (remove after confirming)
  app.ready(() => {
    // print to stdout so we can see exact paths & methods
    console.log('\n=== ROUTE MAP START ===');
    console.log(app.printRoutes());
    console.log('=== ROUTE MAP END ===\n');
  });
});
